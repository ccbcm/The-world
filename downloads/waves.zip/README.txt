网页动态壁纸。打开 index.html 预览；桌面使用需要支持网页壁纸的播放器。CCBCM 当前插件暂不支持此格式。
Vanta by Teng Bao: https://github.com/tengbao/vanta (MIT)